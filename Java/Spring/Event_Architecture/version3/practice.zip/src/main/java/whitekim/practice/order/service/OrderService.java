package whitekim.practice.order.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import whitekim.practice.common.utils.IdempotencyKeyUtils;
import whitekim.practice.item.exception.NotEnoughItemStockException;
import whitekim.practice.member.exception.NotExistMemberException;
import whitekim.practice.item.api.ItemPurchaseApi;
import whitekim.practice.item.api.ItemRollbackApi;
import whitekim.practice.member.api.MemberExistApi;
import whitekim.practice.order.exception.NotExistOrderException;
import whitekim.practice.order.dto.request.ReqOrderInfo;
import whitekim.practice.order.dto.response.RespOrderInfo;
import whitekim.practice.order.entity.Order;
import whitekim.practice.order.repository.OrderRepository;
import whitekim.practice.order.type.OrderStatus;
import whitekim.practice.common.event.OrderRequestPaymentEvent;

import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class OrderService {
    private final MemberExistApi memberExistApi;
    private final ItemPurchaseApi itemPurchaseApi;
    private final ItemRollbackApi itemRollbackApi;
    private final OrderRepository orderRepository;

    // phase 3
    private final KafkaTemplate<String, Object> kafkaTemplate;

    public RespOrderInfo getOrderInfo(Long orderId) {
        Order order = orderRepository
                .findById(orderId)
                .orElseThrow(() ->
                   new NotExistOrderException(orderId)
                );

        return RespOrderInfo.toDto(order);
    }

    public Long processOrder(ReqOrderInfo orderInfo) {
        // 멤버 여부 확인
        boolean isExist = memberExistApi.existMemberById(orderInfo.memberId());

        // 없는데 계속진행하려고?
        if(!isExist) {
            throw new NotExistMemberException();
        }

        Order order = orderInfo.toEntity();
        order = orderRepository.save(order);

        // 주문 전 아이템 재고 확보
        // 주문 전 예샹결제 금액 반환
        BigDecimal purchasePrice = itemPurchaseApi.purchase(orderInfo.itemId(), orderInfo.purchaseCount());

        // 메시지 키 생성
        String key = IdempotencyKeyUtils.generateKey(order.getId());

        // 청구 전송
        kafkaTemplate.send("order-request-payment-event", key, new OrderRequestPaymentEvent(order.getId(), order.getMemberId(), purchasePrice));

        return order.getId();
    }

    public List<RespOrderInfo> getAllOrderInfo() {
        return orderRepository.findAll()
                .stream()
                .map(RespOrderInfo::toDto)
                .toList();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void processSuccessPayment(Long orderId, Long paymentId, BigDecimal chargeAmount) {
        Order order =
                orderRepository.findById(orderId).orElseThrow(() -> new NotExistOrderException(orderId));

        // 주문상태 업데이트 : 실패 => 성공 이벤트 발생
        if(order.getOrderStatus() == OrderStatus.FAILED) {
            order.changeOrderStatus(OrderStatus.PENDING_RESOLUTION);

            log.info("[OrderService] 결제 정보 변경(실패 -> 성공)");
            log.info("[OrderService] 확인 후 처리할 것");

            // 재고를 반환했으므로 다시 확보 시도
            // 아이템 재고 확보 시도
            try {
                log.info("[OrderService] ORDER PENDING | 주문 ID : {}, 결제 ID : {}, 결제금액 : {}, 상품 ID : {}, 주문건수 : {}", orderId, paymentId, chargeAmount, order.getItemId(), order.getPurchaseCount());
                itemPurchaseApi.purchase(order.getItemId(), order.getPurchaseCount());
            } catch (NotEnoughItemStockException e) {
                order.changeOrderStatus(OrderStatus.STOCK_RESERVATION_FAILED);
            }

            return;
        }

        // 주문 최종 생성
        order.processPayment(paymentId, chargeAmount);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void processFailedPayment(Long orderId) {
        Order order =
                orderRepository.findById(orderId).orElseThrow(() -> new NotExistOrderException(orderId));

        // 주문상태 업데이트 : 실패
        order.changeOrderStatus(OrderStatus.FAILED);
        itemRollbackApi.rollbackInventory(order.getItemId(), order.getPurchaseCount());
    }

    // 주문에 대한 처리 상태 반환
    public boolean getOrderStatus(Long orderId) {
        Order order =
                orderRepository.findById(orderId).orElseThrow(() -> new NotExistOrderException(orderId));

        // 주문 상태 확인
        return !(order.getOrderStatus() == OrderStatus.WAITING || order.getOrderStatus() == OrderStatus.FAILED);
    }
}
